export class Tweet {
    public tweetId:number;
    public userId: string;
    public username: string;
    public userTweets:string;
    public createdDate:Date;
}
