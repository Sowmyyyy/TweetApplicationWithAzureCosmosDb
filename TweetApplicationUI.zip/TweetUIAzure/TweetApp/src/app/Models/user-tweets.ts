export class UserTweets {
    public tweetId:number;
    public userId: string;
    public username: string;
    public userTweets:string;
    public createdDate:Date;
    public datecalculated:string;
    public imagename: string;
    public firstName: string;
    public lastName:string;
}
