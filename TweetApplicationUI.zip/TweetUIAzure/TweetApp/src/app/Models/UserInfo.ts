export class UserInfo {
    public id:string;
    public firstname: string;
    public lastname:string;
    public gender:string;
    public dob:Date;
    public emailId:string;
    public password:string;
    public imgname:string;
}
