import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Tweet } from '../Models/tweet';
import { UserInfo } from '../Models/UserInfo';
import { UserComment } from '../Models/user-comment';
import { UserTweets } from '../Models/user-tweets';
import { TweetappService } from '../services/tweetapp.service';
import * as moment from 'moment';

@Component({
  selector: 'app-viewprofile',
  templateUrl: './viewprofile.component.html',
  styleUrls: ['./viewprofile.component.css'],
})
export class ViewprofileComponent implements OnInit {
  username: string;
  id: string;
  user: UserInfo;
  tweetUser: any;
  tweetslist: UserTweets[] = [];
  form: FormGroup
  uname: string;
  commentslist: UserComment[];
  result: number;
  clickedButton: { [key: number]: boolean } = {};
  count: Tweet;
  todaysDataTime = new Date();
  today = new Date();
  date: string;
  text: string;
  constructor(private route: Router, private service: TweetappService) {
    this.Profile();
    this.service.GetAllUsers().subscribe(res=>{
      this.service.users = res;
    });
  }
  Profile() {
    this.id = localStorage.getItem('UserId') || ' ';
    console.log('A', this.id);
    this.username = String(localStorage.getItem('Username') || '{}');
    this.service.GetUserProfile(this.id).subscribe(res => {
      console.log('B', res);
      this.user = res;
    },
      err => {
        console.log(err);
      }
    )
    if (String(localStorage.getItem('UserId') || ' ') != null) {
      this.id = localStorage.getItem('UserId') || ' ';
      this.service.GetTweetsByUser(this.id).subscribe(res => {
        this.tweetslist = res;
        console.log(this.tweetslist)
        this.tweetslist.forEach(element => {
          this.tweetUser = this.service.users.find(x => x.emailId == element.userId);
          element.firstName = this.tweetUser.firstname;
          element.lastName = this.tweetUser.lastname;
          element.imagename = this.tweetUser.imgname;
          this.date = formatDate(this.today, 'yyyy/MM/dd', 'en-US', '+0530')
          localStorage.setItem("Tweets",element.userTweets);
          localStorage.setItem("TweetUserName",element.username);
          localStorage.setItem("TweetUserId",element.userId);
          localStorage.setItem("tweetDate",element.createdDate.toString());
          var created_date = localStorage.getItem('tweetsdate');
          console.log(created_date)
          var text = this.GetTime(created_date);
          element.datecalculated = moment(element.createdDate).fromNow();
          console.log(element.datecalculated);
        });

        console.log(this.tweetslist);
      })
    }
    else {
      alert("Please Login With Credentials...");
    }
  }
  ngOnInit() {

  }
  GetTime(created_date: any) {
    function getDateDiff(startDate: Date, endDate: Date) {
      var diff = endDate.getTime() - startDate.getTime();
      var days = Math.floor(diff / (60 * 60 * 24 * 1000));
      var hours = Math.floor(diff / (60 * 60 * 1000)) - (days * 24);
      var minutes = Math.floor(diff / (60 * 1000)) - ((days * 24 * 60) + (hours * 60));
      var seconds = Math.floor(diff / 1000) - ((days * 24 * 60 * 60) + (hours * 60 * 60) + (minutes * 60));
      if (days == 0) {
        return hours + "h"
      }
      else if (hours == 0) {
        return minutes + "min"
      }
      else if (minutes == 0) {
        return seconds + "sec"
      }
      else {
        return days + "days"
      }
    }
    var diff = getDateDiff(new Date(created_date), new Date(this.todaysDataTime));
    localStorage.setItem("datescalculated", diff);
  }
  Search() {
    this.uname = this.form.value["username"]
    localStorage.setItem("uname", this.uname);
    this.route.navigateByUrl('/SEARCH TWEET');
  }
  logout() {

    localStorage.clear();

  }
  onReset() {
    this.form.reset();
  }
}
