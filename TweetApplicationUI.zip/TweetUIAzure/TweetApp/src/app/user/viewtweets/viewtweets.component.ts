import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Tweet } from 'src/app/Models/tweet';
import { UserInfo } from 'src/app/Models/UserInfo';
import { UserComment } from 'src/app/Models/user-comment';
import { UserTweets } from 'src/app/Models/user-tweets';
import { TweetappService } from 'src/app/services/tweetapp.service';
import * as moment from 'moment';

@Component({
  selector: 'app-viewtweets',
  templateUrl: './viewtweets.component.html',
  styleUrls: ['./viewtweets.component.css']
})
export class ViewtweetsComponent implements OnInit {
  list:UserTweets[];
commentslist:UserComment[];
form:FormGroup;
result:number;
clickedButton : {[key: number] : boolean} ={};
count:Tweet;
id:string;
todaysDataTime:any;
today= new Date();
username:string;
date:string;
text:string;
user:UserInfo;
tweetUser: any;
  constructor(private frombuilder:FormBuilder,private service:TweetappService,private route:Router) { 
    this.Tweets();
    this.service.GetAllUsers().subscribe(res=>{
      this.service.users = res;
    });
  }
Tweets()
{
  this.id = localStorage.getItem('UserId') || ' ' ;
    this.username = String(localStorage.getItem('Username') || '{}');
    this.todaysDataTime = formatDate(this.today, 'yyyy/MM/dd', 'en-US', '+0530');
    this.service.GetUserProfile(this.username).subscribe(res=>
      {
        this.user=res;
        console.log(this.user);
      },
      err=>{
        console.log(err);
      }
      )
    this.GetAllTweets();
}
  ngOnInit(){
   this.form = this.frombuilder.group({
     comment:['']

   })
  }
GetAllTweets()
{
  this.service.GetAllTweets().subscribe(res=>{
    this.list=res;
    console.log(this.list);
    this.list.forEach(element => {
      this.tweetUser = this.service.users.find(x => x.emailId == element.userId);
      element.firstName = this.tweetUser.firstname;
      element.lastName = this.tweetUser.lastname;
      element.imagename = this.tweetUser.imgname;
     this.date=formatDate(this.today,'yyyy/MM/dd','en-US', '+0530')
      localStorage.setItem("Tweets",element.userTweets);
      localStorage.setItem("TweetUserName",element.username);
      localStorage.setItem("TweetUserId",element.userId);
      localStorage.setItem("tweetDate",element.createdDate.toString());
      var created_date=localStorage.getItem('tweetDate');
      var text=this.GetTime(created_date);
      element.datecalculated=moment(element.createdDate).fromNow();
      console.log(element.datecalculated);
    });

    console.log(this.list);
  })
  this.route.navigateByUrl('USER')

}

GetTime(created_date:any)
{
  function getDateDiff(startDate:Date, endDate:Date) {
    var diff = endDate.getTime() - startDate.getTime();
    var days = Math.floor(diff / (60 * 60 * 24 * 1000));
    var hours = Math.floor(((diff / (60 * 60 * 1000)) - (days * 24))-5);
    var minutes = Math.floor((((diff / (60 * 1000)) - ((days * 24 * 60) + (hours * 60)))-32)/60) - 4;
    var seconds = Math.floor((diff / 1000) - ((days * 24 * 60 * 60) + (hours * 60 * 60) + (minutes * 60))/3600);
    if(days<=0 && hours>0)
    {
      return hours+" hours"
    }
    else if(hours<=0)
    {
      return minutes+" minutes"
    }
    else if(minutes<=0)
    {
      return seconds+" seconds"
    }
    else{
      return days+" days"
    }
}
var diff = getDateDiff(new Date(created_date),new Date(this.today));
localStorage.setItem("datecalculated",diff);
}

logout()
  {
    localStorage.clear();
  }
  
onReset()
{
  this.form.reset();
}
}


