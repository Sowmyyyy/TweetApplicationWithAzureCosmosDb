import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Tweet } from 'src/app/Models/tweet';
import { UserInfo } from 'src/app/Models/UserInfo';
import { UserTweets } from 'src/app/Models/user-tweets';
import { TweetappService } from 'src/app/services/tweetapp.service';

@Component({
  selector: 'app-posttweet',
  templateUrl: './posttweet.component.html',
  styleUrls: ['./posttweet.component.css']
})
export class PosttweetComponent implements OnInit {

  form:FormGroup;
  id:string;
  user:UserInfo;
  userlist:UserInfo[];
  tweet:Tweet;
  username:string;
  submitted = false;
  list:UserTweets[];
  public isCollapsed = true;

  constructor(private frombuilder:FormBuilder,private service:TweetappService,private route:Router) { 
    this.id = localStorage.getItem('UserId') || ' ' ;
    this.username = String(localStorage.getItem('Username') || '{}');
    this.isCollapsed = true;
    console.log('AA', this.id);
    this.service.GetUserProfile(this.id).subscribe(res=>
      {
        this.user=res;
        console.log('BB', this.user);
        localStorage.setItem("lastName",this.user.lastname);
        localStorage.setItem("firstName",this.user.firstname);
      },
      err=>{
        console.log(err);
      })
      this.service.GetAllUsers().subscribe(res=>{
        this.service.users = res;
      });
  }

  ngOnInit() {
    this.form = this.frombuilder.group({
      tweets:['', Validators.required],
      like:['']
    })
  }

  onSubmitPost(){
    this.submitted=true;
    if(this.form.invalid){
     return;
    }
      else{
        this.tweet=new Tweet();
      this.tweet.userId=this.id;
      this.tweet.username=this.username;
      this.tweet.userTweets=this.form.value["tweets"];
      this.tweet.createdDate=new Date();
      const payload = Object.assign({}, this.tweet);
     this.service.PostTweet(payload).subscribe(res=>{
       if(res.status == 'New tweet added successfully')
       {
        this.route.navigateByUrl('VIEW-TWEETS');
        alert("Tweet Posted Successfully");
        this.onReset();
       }
      else {
        alert("Failed to Post Tweet");
      }
     },
      err=>{
        alert("Failed to Post Tweet");
        this.onReset();
      });
      }
    }

    onReset(){
      this.submitted=false;
      this.form.reset();
      this.isCollapsed = !this.isCollapsed;
    }

}
